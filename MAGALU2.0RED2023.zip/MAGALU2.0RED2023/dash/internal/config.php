
<?php

$dbhost = "localhost";
$dbuser = "root";
$dbpass = "admin";
$dbname = "kkk";

?>


