<?php

$api_key = '244134f36818b17c72ff027d451de42f';


?>