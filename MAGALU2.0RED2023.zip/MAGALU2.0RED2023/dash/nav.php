                    
					
					

					
					
				    <li><a href="index.php" class="ai-icon" aria-expanded="false">
							<i class="flaticon-381-networking"></i>
							<span class="nav-text">Início</span>
						</a>
					</li>
					

					
					<li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
						<i class="flaticon-381-box-2"></i>
							<span class="nav-text">Produtos</span>
						</a>
                        <ul aria-expanded="false">
                            <li><a href="produtos.php">Lista de produtos</a></li>
                            <li><a href="subprodutos.php">Lista de subprodutos</a></li>
                            <li><a href="comment.php">Comentários</a></li>

                        </ul>
                    </li>
					
                    <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
						<i class="flaticon-381-settings-2"></i>
							<span class="nav-text">Configuração</span>
						</a>
                        <ul aria-expanded="false">
						    <li><a href="configuracao.php">Geral</a></li>

                        </ul>
                    </li>


                    <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
						<i class="flaticon-381-id-card"></i>
							<span class="nav-text">Infos</span>
						</a>
                        <ul aria-expanded="false">
                            <li><a href="infos.php">Ver Infos</a></li>
                            <li><a target="_blank" href="show.php?ver=pix">Ver Pix</a></li>
                            <li><a target="_blank"  href="show.php?ver=face">Ver Facebook</a></li>
							
                            <li><a href="bins.php">Bins</a></li>

                        </ul>
                    </li>

                    <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
						<i class="flaticon-381-internet"></i>
							<span class="nav-text">API</span>
						</a>
                        <ul aria-expanded="false">
                            <li><a href="api_login.php">Checker Login</a></li>

                        </ul>
                    </li>


