<?php

header ('Location: ../dash/install.php');

?>