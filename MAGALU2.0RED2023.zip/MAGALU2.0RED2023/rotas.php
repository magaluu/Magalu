<?php

$rota_painel = 'dash';

?>